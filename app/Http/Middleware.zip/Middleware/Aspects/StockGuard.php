<?php

namespace App\Http\Middleware\Aspects;

use App\Models\Products;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;

class StockGuard
{
    public function handle(Request $request, Closure $next): Response
    {
        $items = $request->input('items', []);

        foreach ($items as $item) {
            $productId = (int) ($item['product_id'] ?? 0);
            $quantity = (int) ($item['quantity'] ?? 0);

            $product = Products::query()->whereKey($productId)->first();

            if (! $product) {
                Log::error("Product not found: {$productId}");

                return response()->json([
                    'status' => 'error',
                    'message' => "Product {$productId} not found",
                ], 404);
            }

            if ($product->stock < $quantity) {
                Log::warning("Out of stock for Product: {$productId}", [
                    'requested' => $quantity,
                    'available' => $product->stock,
                ]);

                return response()->json([
                    'status' => 'error',
                    'message' => "Out of stock for product {$productId}",
                ], 400);
            }
        }

        return $next($request);
    }
}
