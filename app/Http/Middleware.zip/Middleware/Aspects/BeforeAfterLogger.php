<?php

namespace App\Http\Middleware\Aspects;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;

class BeforeAfterLogger
{
    public function handle(Request $request, Closure $next): Response
    {
        $startedAt = microtime(true);

        Log::info('[AOP][BEFORE]', [
            'method' => $request->method(),
            'path' => $request->path(),
            'ip' => $request->ip(),
        ]);

        $response = $next($request);

        Log::info('[AOP][AFTER]', [
            'method' => $request->method(),
            'path' => $request->path(),
            'status' => $response->getStatusCode(),
            'duration_ms' => round((microtime(true) - $startedAt) * 1000, 2),
        ]);

        return $response;
    }
}
