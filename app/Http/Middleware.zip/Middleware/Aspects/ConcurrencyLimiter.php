<?php

namespace App\Http\Middleware\Aspects;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;

class ConcurrencyLimiter
{
    public function handle(Request $request, Closure $next): Response
    {
        $max = (int) config('project.max_concurrent_orders', 10);
        $key = 'aop:active_orders';

        if (! Cache::has($key)) {
            Cache::put($key, 0, now()->addMinutes(5));
        }

        $current = (int) Cache::increment($key);
        Cache::put($key, $current, now()->addMinutes(5));

        if ($current > $max) {
            Cache::decrement($key);

            Log::warning('Capacity Control: request rejected because the concurrent limit was exceeded.', [
                'active' => $current,
                'limit' => $max,
                'path' => $request->path(),
            ]);

            return response()->json([
                'message' => 'Server busy, try again later',
            ], 503);
        }

        try {
            return $next($request);
        } finally {
            Cache::decrement($key);
        }
    }
}
